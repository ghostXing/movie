  (function (angular) {
      'use strict';

      angular.module('myApp.com_soon', ['ngRoute',"moviecat.service"])

          .config(['$routeProvider', function($routeProvider) {
              $routeProvider.when('/com_soon/:page', {
                  templateUrl: 'com_soon/com_soon.html',
                  controller: 'View2Ctrl'
              });
          }])

          .controller('View2Ctrl', ["$scope", "$route", "$routeParams", "httpService",
              function ($scope,$route, $routeParams, httpService) {
                  // $http({method:"GET",url:"/app/data.json"})
                  //     .then(function successCallBack(response) {
                  //         $scope.text = response.data.title;
                  //         $scope.data = response.data;
                  //     },function errorCallBack(error) {
                  //         $scope.text = "页面错误"+error.status;
                  //     });
                  var count = 2;
                  var page = $routeParams.page;
                  $scope.currentPage =parseInt(page);
                  var start = (page - 1) * count;
                  $scope.flag = false;
                  httpService.jsonp("https://api.douban.com/v2/movie/coming_soon",
                      {start: start, count: count},
                      function (data) {
                          $scope.data = data;
                          $scope.title = data.title;
                          $scope.total = data.total;
                          $scope.pageCount = Math.ceil($scope.total / count);
                          $scope.flag = true;
                          $scope.$apply();
                      });

                  $scope.play = function (page) {
                      if (page >= 1 && page <= $scope.pageCount) {
                          $route.updateParams({page:page});
                      }
                  };
              }]);

  })(angular);