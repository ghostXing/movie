  (function (angular) {
      'use strict';

      angular.module('myApp.top250', ['ngRoute',"moviecat.service"])

          .config(['$routeProvider', function($routeProvider) {
              $routeProvider.when('/top250/:page', {
                  templateUrl: 'top250/top250.html',
                  controller: 'View3Ctrl'
              });
          }])

          .controller('View3Ctrl', ["$scope", "$route", "$routeParams", "httpService",
              function ($scope,$route, $routeParams, httpService) {
                  // $http({method:"GET",url:"/app/data.json"})
                  //     .then(function successCallBack(response) {
                  //         $scope.text = response.data.title;
                  //         $scope.data = response.data;
                  //     },function errorCallBack(error) {
                  //         $scope.text = "页面错误"+error.status;
                  //     });
                  var count = 2;
                  var page = $routeParams.page;
                  $scope.currentPage =parseInt(page);
                  var start = (page - 1) * count;
                  $scope.flag = false;
                  httpService.jsonp("https://api.douban.com/v2/movie/top250",
                      {start: start, count: count},
                      function (data) {
                          $scope.data = data;
                          $scope.title = data.title;
                          $scope.total = data.total;
                          $scope.pageCount = Math.ceil($scope.total / count);
                          $scope.flag = true;
                          $scope.$apply();
                      });

                  $scope.play = function (page) {
                      if (page >= 1 && page <= $scope.pageCount) {
                          $route.updateParams({page:page});
                      }
                  };
              }]);

  })(angular);